## Upload Section

This folder is designated for all participants to upload their work.

### Naming Convention for Notebooks

Please adhere to the following naming convention for your notebook:
- The notebook should be named as: `"first_letter_of_the_name_of_each_participant.ipynb"`

For example, if your name is BINATNA DATA, the notebook should be named as `B.ipynb`.

Thank you for your cooperation!
