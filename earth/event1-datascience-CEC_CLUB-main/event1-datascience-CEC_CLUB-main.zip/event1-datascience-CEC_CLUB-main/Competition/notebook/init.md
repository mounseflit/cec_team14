# Competition Description
